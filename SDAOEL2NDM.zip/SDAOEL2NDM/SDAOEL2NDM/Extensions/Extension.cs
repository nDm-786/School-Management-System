﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDAOEL2NDM.Extensions
{
    internal class Extension
    {
        public void ExposeEndpoints()
        {
            Console.WriteLine("This Extension helps providing data in order to integrate in Third Party Apps");
        }

        public void UsePublicData()
        {
            // Use system public data to third-party apps
        }
    }
}
