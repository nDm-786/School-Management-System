﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDAOEL2NDM.Notifications
{
    internal class NotificationService : INotificationService
    {
        public void ScheduleNewsletterEmail(User user, string content)
        {
            // It sends a newsletter email to the user
            Console.WriteLine("{0} sent to {1} Id {2}", content, user.Name, user.UserId);
        }

        public void ScheduleTextNotification(User user, string message)
        {
            // It sends a text notification to the user
            Console.WriteLine("{0} sent to {1} Id {2}", content, user.Name, user.UserId);
        }

        public void ScheduleInAppNotification(User user, string message)
        {
            // It sends an in-app notification to the user
            Console.WriteLine("{0} sent to {1} Id {2}", content, user.Name, user.UserId);
        }
    }
}
